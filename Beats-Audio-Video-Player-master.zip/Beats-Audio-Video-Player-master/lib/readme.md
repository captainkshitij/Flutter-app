Create a file named "_keys.dart_" and write  __const String API_KEY = 'YouTube API key';__ in that file.
<br>
You can your API key from <a href="https://console.developers.google.com/">Google API</a>.
