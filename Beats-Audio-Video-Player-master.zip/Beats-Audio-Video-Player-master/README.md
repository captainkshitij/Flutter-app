# Flutter App Development‼️

Here I built an Android app named "Beats: Audio Video Player" using flutter. This app will play audio and video locally i.e, from assets as well as it has a feature to run online YouTube videos.

